﻿README
—---------------------


Open the group_4_assignment_4.pde file. Make sure the “Sound” library has been installed in Processing. Press the run button in Processing to start the program.